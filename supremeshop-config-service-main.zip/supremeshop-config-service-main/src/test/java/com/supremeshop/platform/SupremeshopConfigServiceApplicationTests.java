package com.supremeshop.platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupremeshopConfigServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
